from setuptools import setup, Extension
from Cython.Build import cythonize
import numpy

# For GCC/Clang on Linux/macOS
compile_args = ['-fopenmp']
link_args = ['-fopenmp']

# For MSVC on Windows, the flags would be:
# compile_args = ['/openmp']
# link_args = []

extensions = [
    Extension("Cov_g", ["Cov_g.pyx"]),
]
setup(
    # ext_modules=cythonize("Cov_g.pyx"),
    ext_modules=cythonize(extensions),
    include_dirs=[numpy.get_include()]
)